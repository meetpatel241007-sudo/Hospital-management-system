#include<iostream>
#include<vector>
#include<queue>
#include<algorithm>
#include<limits>
using namespace std;

class Patient
{
public:
    string name;
    int age;
    int priority;

    Patient(string n, int a, int p)
    {
        name = n;
        age = a;
        priority = p;
    }
};

vector<Patient> patients;
queue<Patient> waitingQueue;

// Add Patient
void addPatient()
{
    string name;
    int age, priority;

    cout<<"Enter Name: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, name);

    cout<<"Enter Age: ";
    cin>>age;

    cout<<"Enter Priority (1-High, 2-Medium, 3-Low): ";
    cin>>priority;

    patients.push_back(Patient(name, age, priority));
    cout<<"Patient Added Successfully!\n";
}

// Display Patients
void displayPatients()
{
    if(patients.empty())
    {
        cout<<"No patients found.\n";
        return;
    }

    for(int i=0; i<patients.size(); i++)
    {
        cout<<"\nName: "<<patients[i].name;
        cout<<"\nAge: "<<patients[i].age;
        cout<<"\nPriority: "<<patients[i].priority<<"\n";
    }
}

// Search Patient
void searchPatient()
{
    string name;
    cout<<"Enter Name to Search: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, name);

    for(auto p : patients)
    {
        if(p.name == name)
        {
            cout<<"Found!\n";
            cout<<"Age: "<<p.age<<" Priority: "<<p.priority<<endl;
            return;
        }
    }
    cout<<"Patient not found.\n";
}

// Sort by Priority
void sortByPriority()
{
    sort(patients.begin(), patients.end(), [](Patient a, Patient b){
        return a.priority < b.priority;
    });

    cout<<"Patients sorted by priority!\n";
}

// Add to Queue
void addToQueue()
{
    if(patients.empty())
    {
        cout<<"No patients available.\n";
        return;
    }

    int index;
    cout<<"Enter Patient Index (starting from 0): ";
    cin>>index;

    if(index >= 0 && index < patients.size())
    {
        waitingQueue.push(patients[index]);
        cout<<"Added to Queue!\n";
    }
    else
    {
        cout<<"Invalid index.\n";
    }
}

// Remove from Queue
void removeFromQueue()
{
    if(waitingQueue.empty())
    {
        cout<<"Queue is empty.\n";
        return;
    }

    cout<<"Removed: "<<waitingQueue.front().name<<endl;
    waitingQueue.pop();
}

// Display Queue
void displayQueue()
{
    if(waitingQueue.empty())
    {
        cout<<"Queue is empty.\n";
        return;
    }

    queue<Patient> temp = waitingQueue;

    while(!temp.empty())
    {
        cout<<temp.front().name<<" (Priority: "<<temp.front().priority<<")\n";
        temp.pop();
    }
}

// MAIN
int main()
{
    int choice;

    do {
        cout<<"\n--- Hospital Management ---\n";
        cout<<"1. Add Patient\n";
        cout<<"2. Display Patients\n";
        cout<<"3. Search Patient\n";
        cout<<"4. Sort by Priority\n";
        cout<<"5. Add to Waiting Queue\n";
        cout<<"6. Remove from Queue\n";
        cout<<"7. Display Queue\n";
        cout<<"0. Exit\n";
        cout<<"Enter Choice: ";
        cin>>choice;

        switch(choice)
        {
            case 1: addPatient(); break;
            case 2: displayPatients(); break;
            case 3: searchPatient(); break;
            case 4: sortByPriority(); break;
            case 5: addToQueue(); break;
            case 6: removeFromQueue(); break;
            case 7: displayQueue(); break;
            case 0: cout<<"Exiting...\n"; break;
            default: cout<<"Invalid choice!\n";
        }

    } while(choice != 0);

    return 0;
}